#ifndef INTINFO_H_
#define INTINFO_H_

uint8_t HELLO = 0b00000000;
uint8_t Sync = 0b00000001;
uint8_t Dados0 = 0b00000010;
uint8_t Dados1 = 0b00000011;
uint8_t Dados2 = 0b00000100;
uint8_t STOP = 0b00000101;

#endif
