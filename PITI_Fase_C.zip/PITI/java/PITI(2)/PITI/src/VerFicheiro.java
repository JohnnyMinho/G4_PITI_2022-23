public interface VerFicheiro {
 void openFileViewer(String Path, String file_extension);
}
