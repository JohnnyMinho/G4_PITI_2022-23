import com.fazecast.jSerialComm.SerialPort;
import static java.lang.Thread.sleep;
import static net.fec.openrq.parameters.ParameterChecker.maxAllowedDataLength;
import static net.fec.openrq.parameters.ParameterChecker.minAllowedNumSourceBlocks;

import net.fec.openrq.*;
import net.fec.openrq.encoder.DataEncoder;
import net.fec.openrq.encoder.SourceBlockEncoder;
import net.fec.openrq.parameters.FECParameters;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class F1_2 {

    private static final int SYMB_SIZE = 32;

    public static final long MAX_DATA_LEN = maxAllowedDataLength(SYMB_SIZE);

public static void main(String[] args) throws IOException, InterruptedException {

//https://fazecast.github.io/jSerialComm/

        //Vars para o FEC RaptorQ
        int numSourceSymbols = 10;
        int numSubSymbols = 3;
        int payloadSize = 100;


        long inicio;
        long fim;
        long tempo;
        int opcao;
        Scanner sc = new Scanner(System.in);

            SerialPort[] p = SerialPort.getCommPorts();
            if (p.length == 0) {
                System.out.println("Portas indisponiveis");
                sleep(2000);
                System.exit(0);
            }
   int i = 1;
            int k=0;
   int escolha = 0;
            while(true) {
                for (SerialPort ps : p) {     //Seleção da porta série a usar
                    System.out.println("  [" + i++ + "] " + "--> " + ps.getSystemPortName());
                    k++;
                }
                escolha = sc.nextInt();
                if (escolha <= k && escolha > 0){
                        k = escolha;
                break;
   }
                k=0;
                i=1;
            }
   SerialPort ps = p[--k];
            ps.openPort();

            ps.setComPortParameters(115200,8,0,0);   //Definir a Confg da Porta serie
        
            Scanner s = new Scanner(System.in);
                System.out.println("  [1] --> Enviar TXT ");
                System.out.println("  [2] --> Receber TXT ");
                System.out.println("  [3] --> ")
                
                System.out.println("Option:");
                    opcao = s.nextInt();
            
            switch (opcao) {
                case 1:
                    inicio = System.currentTimeMillis();
                    enviar(ps,1);              //Método de envio
                    fim = System.currentTimeMillis();
                    tempo = (fim - inicio);
                    System.out.println("enviado em "+ tempo + "ms");
                    break;
                case 2:
                    receber(ps,1);//Método para receber txt
                    ps.closePort();
                    break;

            }
        System.exit(1);
}


public static void receber(SerialPort port,int aux) throws IOException {
    if(aux ==1) //receber txt
    {   
        byte[] cab = new byte[5];
        while (port.bytesAvailable() < 5 ) {//Espera pelo envio do último byte
        }
        port.readBytes(cab, 5);
        int val = (int)cab[3];
        byte[] bytes = new byte[val];
        while (port.bytesAvailable() < val) {//Espera pelo envio do último byte
        }{
                    port.readBytes(flag,1 );
                    if(flag[0]==1){
                        i=1;
                    }
                }
        port.readBytes(bytes, val);    //lê os bytes recebidos pela porta série
        Files.write(new File("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\texto.txt").toPath(), bytes);  //Cria o ficheiro de texto
        byte[] fix = new byte[10];
        while (port.bytesAvailable() < 10) {//Espera pelo envio do último byte
        }
        port.readBytes(fix, 10);
    }
}

    public FECParameters definenewparams(long LenDados){ //O método escolhido foi o do 2º exemplo presente no github da API do OpenRQ

        if (LenDados > MAX_DATA_LEN) {
            throw new IllegalArgumentException("data length is too large");
        }
        int numSBs = minAllowedNumSourceBlocks(LenDados, SYMB_SIZE);
        return FECParameters.newParameters(LenDados, SYMB_SIZE, numSBs);
    }

    public static ArrayDataEncoder getEncoder(byte[] data, FECParameters fecParams) {
        return OpenRQ.newEncoder(data, fecParams);
    }

   /* public static ArrayDataDecoder getdeEncoder(byte[] data, FECParameters fecParams) {
        return OpenRQ.newDecoder(fecParams, ); //Ver como fica o decoder
    }*/

    public static void encodeData(DataEncoder dataEnc) {

        for (SourceBlockEncoder sbEnc : dataEnc.sourceBlockIterable()) {
            encodeSourceBlock(sbEnc);
        }
    }

    private static byte[] encodeSourceBlock(SourceBlockEncoder sbEnc) {
        // número de bits de redundância
        int nr = 4;
        int contador = 0;
        byte[] pacote = new byte[32+nr];

        // Introduz todos os pacotes de dado
        for (EncodingPacket pac : sbEnc.sourcePacketsIterable()) {
            pac.writeTo(pacote);
            if(contador > 32+nr){
                System.out.println("Tagala");
            }
            contador++;
        }

        // Introduz
        for (EncodingPacket pac : sbEnc.repairPacketsIterable(nr)) {
            pac.writeTo(pacote);
            if(contador > 32+nr){
                System.out.println("Tagala");
            }
            contador++;
        }
        return pacote;
    }

    public static byte[] formularCabeçalho(int tamanho_file, int n_envio, int tipo, int n_fluxo){
        byte[] cabecalho = new byte[5];
        int tamanho_total = 0;
        cabecalho[0] = 0b00000010;
        cabecalho[1] = (byte) tipo;
        cabecalho[2] = (byte) tamanho_file;
        cabecalho[3] = (byte) n_envio;
        cabecalho[4] = (byte) n_fluxo;
        cabecalho[5] = '\0';
        return cabecalho;
    }



    //Método para enviar o ficheiro de texto
    public static void enviar(SerialPort port,int aux) throws IOException 
    {
        int b=32;
        if(aux ==1) // enviar texto
        {
        byte[] bytesFromFile = Files.readAllBytes(Paths.get("/home/johnnyminho/teste.txt"));//Converte o ficheiro de texto para um array de bytes
           int i=0,j=0;
           byte[] flag =new byte[1];
           flag[0]=0;
           while(true) {
                while(i==0){
                    port.readBytes(flag,1 );
                    if(flag[0]==1){
                        i=1;
                    }
                }
                if(i==1){
                    if(bytesFromFile.length<b){
                        b = bytesFromFile.length - j; //Assim evitamos a exception OutOfBounds
                    }
                    pacote =
                    byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                    System.out.println("Resultado:" + pacote);
                    port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
                    j=j+b;
                    i=0;
                }

           }
        }
   
    }
    public static void enviarConversa(SerialPort port,int aux) throws IOException
    {

        int b=32;
        if(aux ==1) // enviar texto
        {
            byte[] bytesFromFile = Files.readAllBytes(Paths.get("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt"));//Converte o ficheiro de texto para um array de bytes
            ArrayDataEncoder encoder_temp = getEncoder(bytesFromFile,)
            if(bytesFromFile.length<b){
                b=bytesFromFile.length;
            }
            int i=0,j=0;
            byte[] flag =new byte[1];
            flag[0]=0;
            while(true)
            {
                while(i==0){
                    port.readBytes(flag,1 );
                    if(flag[0]==1){
                        i=1;
                    }
                }
                if(i==1){
                    byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                    port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
                    j=j+b;
                    i=0;
                }

            }
        }

    }
}
