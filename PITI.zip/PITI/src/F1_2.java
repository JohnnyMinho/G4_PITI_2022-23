import com.backblaze.erasure.ReedSolomon;
import com.fazecast.jSerialComm.SerialPort;
import static java.lang.Thread.sleep;
import static net.fec.openrq.parameters.ParameterChecker.maxAllowedDataLength;
import static net.fec.openrq.parameters.ParameterChecker.minAllowedNumSourceBlocks;

import net.fec.openrq.*;
import net.fec.openrq.encoder.DataEncoder;
import net.fec.openrq.encoder.SourceBlockEncoder;
import net.fec.openrq.parameters.FECParameters;

import javax.xml.crypto.Data;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class F1_2 {

    private static final int SYMB_SIZE = 32;

    public static final long MAX_DATA_LEN = maxAllowedDataLength(SYMB_SIZE);

    public static void main(String[] args) throws IOException, InterruptedException
    {

//https://fazecast.github.io/jSerialComm/

        //Vars para o FEC RaptorQ
        int numSourceSymbols = 10;
        int numSubSymbols = 3;
        int payloadSize = 100;


        long inicio;
        long fim;
        long tempo;
        int opcao;
        Scanner sc = new Scanner(System.in);

        SerialPort[] p = SerialPort.getCommPorts();
        if (p.length == 0) {
            System.out.println("Portas indisponiveis");
            sleep(2000);
            System.exit(0);
        }
        int i = 1;
        int k=0;
        int escolha = 0;
        while(true) {
            for (SerialPort ps : p) {     //Seleção da porta série a usar
                System.out.println("  [" + i++ + "] " + "--> " + ps.getSystemPortName());
                k++;
            }
            escolha = sc.nextInt();
            if (escolha <= k && escolha > 0){
                k = escolha;
                break;
            }
            k=0;
            i=1;
        }
        SerialPort ps = p[--k];
        ps.openPort();

        ps.setComPortParameters(115200,8,0,0);   //Definir a Confg da Porta serie

        Scanner s = new Scanner(System.in);
        System.out.println("  [1] --> Enviar Ficheiro ");
        System.out.println("  [2] --> Receber ");
        System.out.println("  [3] --> Enviar mensagem");

        System.out.println("Opçao:");
        opcao = s.nextInt();

        switch (opcao) {
            case 1:
                inicio = System.currentTimeMillis();
                enviar(ps); //Método de envio
                fim = System.currentTimeMillis();
                tempo = (fim - inicio);
                System.out.println("enviado em "+ tempo + "ms");
                break;
            case 2:
                receber(ps);//Método para receber txt
                ps.closePort();
                break;
            case 3:
                enviarConversa(ps);
                ps.closePort();
                break;
        }
        System.exit(1);
    }


    public static void receber(SerialPort port) throws IOException {

        byte[] cab = new byte[5];
        while (port.bytesAvailable() < 5 ) {//Espera pelo envio do último byte
        }
        port.readBytes(cab, 5);
        int val = (int)cab[3];
        byte[] bytes = new byte[val];
        int i;
        byte[] flag = new byte[1];
        while (port.bytesAvailable() < val) {//Espera pelo envio do último byte
        }{

            port.readBytes(flag,1 );
            if(flag[0]==1){
                i=1;
            }
        }
        port.readBytes(bytes, val);    //lê os bytes recebidos pela porta série
        Files.write(new File("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\texto.txt").toPath(), bytes);  //Cria o ficheiro de texto
        byte[] fix = new byte[10];
        while (port.bytesAvailable() < 10) {//Espera pelo envio do último byte
        }
        port.readBytes(fix, 10);
    }



    public static byte[] formularCabeçalho(int tamanho_dados, int n_envio, int tipo, int n_fluxo){

        byte[] cabecalho = new byte[5];
        int tamanho_total = 0;
        cabecalho[0] = 0b00000010;
        cabecalho[1] = (byte) tipo;
        cabecalho[2] = (byte) tamanho_dados;
        cabecalho[3] = (byte) n_envio;
        cabecalho[4] = (byte) n_fluxo;
        cabecalho[5] = '\0';
        return cabecalho;
    }
    public static byte[] trama_inicio(int tamanho_file, String tipo_file, String nome){
        byte[] trama = new byte[22];
        trama[0]= 0b00000010;
        trama[1]= 0b00000000;//hello
        trama[2] = (byte) tamanho_file;
        byte aux[] = tipo_file.getBytes();
        System.arraycopy(aux, 0, trama, 3, 6);
        byte aux2[] = tipo_file.getBytes();
        System.arraycopy(aux2, 0, trama, 9, 12);
        trama[21]= 0b00000011;
        trama[22]='\0';

        return trama;
    }

    //Tentativa com Reed-Solomon através da biblioteca JavaReedSolomon da BackBlaze
//Ainda tenho de rever o método, mas o que estamos a fazer é dividir a mensagem em N blocos (as data_shards) estas são então acompanhadas pelos parity_shards.
    public static byte[][] codificarRS(byte[] mensagem){
        final int DATA_SHARDS = 4; //N = 4
        final int PARITY_SHARDS = 2; // K = 2
        final int TOTAL_SHARDS = 6; // N-K = 12 (distância) máximo de erros corrigidos -> (N-K)/2 = 8
        // final int BYTES_IN_INT = 4;

        int conta_bytes = 0;
        for (byte byte_lido:mensagem) {
            if(byte_lido != 0){
                conta_bytes++;
            }
        }

        //Verificamos se têmos uma mensagem com conteúdo
        //Caso não tenha, a função ira returnar um array com um *.
        //Caso A mensagem não tenha bytes suficientes para se usar o esquema pretendido, é lhe adicionado padding com '*'
        if (conta_bytes == 0) {
            byte[][] error_array = new byte[1][1];
            error_array[0][0] = '*';
            System.out.println("A mensagem não têm conteúdo");
            return error_array;
        }
        else if((conta_bytes % 4) != 0){
            while(conta_bytes % 4 != 0) {
                conta_bytes++;
            }
        }
        byte[] mensagem_used = new byte[conta_bytes]; //Como no Java a definição das variáveis têm de ser indicada fora das condições / loops de modo a ser usada fora dos mesmos. Utilizamos este método
        int contador = 0;
        while(contador != conta_bytes) {
            if (mensagem[contador] == 0) {
                mensagem[contador] = '#';
            }else{
                mensagem_used[contador] = mensagem[contador];
            }
            contador++;
        }

        //O ficheiro não pode avançar o tamanho máximo de uma variável INT (2147483647)
        final int tamanhoMSG = mensagem_used.length;

        final int shardSize = tamanhoMSG/DATA_SHARDS;

        // Create a buffer holding the file size, followed by
        // the contents of the file.

        final int bufferSize = shardSize * DATA_SHARDS;
        final byte [] allBytes = new byte[bufferSize];

        // Make the buffers to hold the shards.
        byte [] [] shards = new byte [TOTAL_SHARDS] [shardSize];

        // Fill in the data shards
        for (int i = 0; i < DATA_SHARDS; i++) {
            System.arraycopy(allBytes, i * shardSize, shards[i], 0, shardSize);
        }

        // Use Reed-Solomon to calculate the parity.
        ReedSolomon reedSolomon = new ReedSolomon(DATA_SHARDS, PARITY_SHARDS);
        reedSolomon.encodeParity(shards, 0, shardSize);
        System.out.println(Arrays.deepToString(shards));
        return shards;

        // Write out the resulting files.
        /*
            for (int i = 0; i < TOTAL_SHARDS; i++) {
                File outputFile = new File(
                        inputFile.getParentFile(),
                        inputFile.getName() + "." + i);
                OutputStream out = new FileOutputStream(outputFile);
                out.write(shards[i]);
                out.close();
                System.out.println("wrote " + outputFile);
            }
            */

    }

//Tentativa Com o RaptorQ através da biblioteca openRQ

    public FECParameters definenewparams(long LenDados){ //O método escolhido foi o do 2º exemplo presente no github da API do OpenRQ

        if (LenDados > MAX_DATA_LEN) {
            throw new IllegalArgumentException("data length is too large");
        }
        int numSBs = minAllowedNumSourceBlocks(LenDados, SYMB_SIZE);
        return FECParameters.newParameters(LenDados, SYMB_SIZE, numSBs);
    }

    public static ArrayDataEncoder getEncoder(byte[] data, FECParameters fecParams) {
        return OpenRQ.newEncoder(data, fecParams);
    }

   /* public static ArrayDataDecoder getdeEncoder(byte[] data, FECParameters fecParams) {
        return OpenRQ.newDecoder(fecParams, ); //Ver como fica o decoder
    }*/

    public static void encodeData(DataEncoder dataEnc) {

        for (SourceBlockEncoder sbEnc : dataEnc.sourceBlockIterable()) {
            encodeSourceBlock(sbEnc);
        }
    }

    private static byte[] encodeSourceBlock(SourceBlockEncoder sbEnc) {
        // número de bits de redundância
        int nr = 4;
        int contador = 0;
        byte[] pacote = new byte[32+nr];

        // Introduz todos os pacotes de dado
        for (EncodingPacket pac : sbEnc.sourcePacketsIterable()) {
            pac.writeTo(pacote);
            if(contador > 32+nr){
                System.out.println("Tagala");
            }
            contador++;
        }

        // Introduz
        for (EncodingPacket pac : sbEnc.repairPacketsIterable(nr)) {
            pac.writeTo(pacote);
            if(contador > 32+nr){
                System.out.println("Tagala");
            }
            contador++;
        }
        return pacote;
    }

    //-----------------------------------------------------------------


    //Método para enviar o ficheiro de texto
    public static void enviar(SerialPort port) throws IOException
    {
        int b=32;
        Scanner scan = new Scanner(System.in);
        //C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt
        System.out.println("Introduza path do ficheiro");
        String path = scan.nextLine();
        String[] partes = path.split("\\");
        String p="";
        for (String parte : partes) {
            p=parte;
        }
        String[] partes2 = p.split(".");


        byte[] bytesFromFile = Files.readAllBytes(Paths.get(path));//Converte o ficheiro de texto para um array de bytes
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        int cont=0;
        byte[] trama_inicial=trama_inicio(bytesFromFile.length, partes2[1], partes2[0]);
        while(true) {

            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                    port.writeBytes(trama_inicial,trama_inicial.length);
                }
            }
            if(i==1){
                if(bytesFromFile.length<b){
                    b = bytesFromFile.length - j; //Assim evitamos a exception OutOfBounds
                }
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                j=j+b;
                System.out.println("Resultado:" );
                byte[] cab=formularCabeçalho(cont, subArray.length, 3, 0);
                byte[] subArray2 = Arrays.copyOfRange(subArray,cab.length,cab.length+j);
                port.writeBytes(subArray2,subArray2.length);  //Envia para a porta série o array de bytes
                cont++;
                i=0;
            }

        }


    }
    public static void enviarConversa(SerialPort port) throws IOException
    {
        int b=32;

        byte[] bytesFromFile = Files.readAllBytes(Paths.get("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt"));//Converte o ficheiro de texto para um array de bytes
        //ArrayDataEncoder encoder_temp = getEncoder(bytesFromFile,)
        if(bytesFromFile.length<b){
            b=bytesFromFile.length;
        }
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        while(true)
        {
            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                }
            }
            if(i==1){
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
                j=j+b;
                i=0;
            }

        }

    }

}