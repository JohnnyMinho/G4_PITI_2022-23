import com.fazecast.jSerialComm.SerialPort;
import static java.lang.Thread.sleep;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;


public class F1_2 {

public static void main(String[] args) throws IOException, InterruptedException {

//https://fazecast.github.io/jSerialComm/

        long inicio;
        long fim;
        long tempo;
        int opcao;
        try (Scanner sc = new Scanner(System.in)) {
            SerialPort[] p = SerialPort.getCommPorts();
            if (p.length == 0) {
                System.out.println("Portas indisponiveis");
                sleep(2000);
                System.exit(0);
            }
   int i = 1;
            int k=0;
   int escolha = 0;
            while(true) {
                for (SerialPort ps : p) {     //Seleção da porta série a usar
                    System.out.println("  [" + i++ + "] " + "--> " + ps.getSystemPortName());
                    k++;
                }
                escolha = sc.nextInt();
                if (escolha <= k && escolha > 0){
                        k = escolha;
                break;
   }
                k=0;
                i=1;
            }
   SerialPort ps = p[--k];
            ps.openPort();

            ps.setComPortParameters(115200,8,1,0);   //Definir a Confg da Porta serie

            try (Scanner s = new Scanner(System.in)) {
                System.out.println("  [1] --> Enviar TXT ");
                System.out.println("  [2] --> Receber TXT ");   

                
                System.out.println("Option:");
                    opcao = s.nextInt();
            }
            switch (opcao) {
                case 1:
                    inicio = System.currentTimeMillis();
                    enviar(ps,1);              //Método de envio
                    fim = System.currentTimeMillis();
                    tempo = (fim - inicio);
                    System.out.println("enviado em "+ tempo + "ms");
                    break;
                case 2:
                    receber(ps,1);//Método para receber txt
                    ps.closePort();
                    break;

            }
        }

        System.exit(1);
}


public static void receber(SerialPort p,int aux) throws IOException {
    if(aux ==1) //receber txt
    {   
        byte[] cab = new byte[5];
        while (p.bytesAvailable() < 5 ) {//Espera pelo envio do último byte
        }
        p.readBytes(cab, 5); 
        int val = (int)cab[3];
        byte[] bytes = new byte[val];
        while (p.bytesAvailable() < val) {//Espera pelo envio do último byte
        }
        p.readBytes(bytes, val);    //lê os bytes recebidos pela porta série
        Files.write(new File("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\texto.txt").toPath(), bytes);  //Cria o ficheiro de texto
        byte[] fix = new byte[10];
        while (p.bytesAvailable() < 10) {//Espera pelo envio do último byte
        }
        p.readBytes(fix, 10);  
    
    
    
    }
}

    //Método para enviar o ficheiro de texto
    public static void enviar(SerialPort port,int aux) throws IOException 
    {
        int b=255;
        if(aux ==1) // enviar texto
        {
        byte[] bytesFromFile = Files.readAllBytes(Paths.get("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt"));//Converte o ficheiro de texto para um array de bytes
       if(bytesFromFile.length<b){
        b=bytesFromFile.length;
       }
       int i=0,j=0;
       byte[] flag =new byte[1];
       flag[0]=0;
       while(true)
       {
    
       while(i==0){
        port.readBytes(flag,1 );
        if(flag[0]==1){
            i=1;
        }
       }
       if(i==1){
        byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
        port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
        j=j+b;
        i=0;
       }
        
        }
        }
   
    }
}
