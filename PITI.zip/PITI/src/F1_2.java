import com.backblaze.erasure.ReedSolomon;
import com.fazecast.jSerialComm.SerialPort;
import static java.lang.Thread.sleep;
import static net.fec.openrq.parameters.ParameterChecker.maxAllowedDataLength;
import static net.fec.openrq.parameters.ParameterChecker.minAllowedNumSourceBlocks;
import javax.swing.*;
import java.awt.*;
import net.fec.openrq.*;
import net.fec.openrq.encoder.DataEncoder;
import net.fec.openrq.encoder.SourceBlockEncoder;
import net.fec.openrq.parameters.FECParameters;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;

public class F1_2 {

    private MétodosCorrErros CorrErros= new MétodosCorrErros(); //Para aceder aos métoos da correção de erros
    private VisualizadordeFicheiros VerFile = new VisualizadordeFicheiros();

    public static final long MAX_DATA_LEN = 32; //O Máximo de bytes por bloco é 32 bytes, os bytes de paridade que acompanham os mesmos na mensagem, não fazem parte deste limite

    public static void main(String[] args) throws IOException, InterruptedException
    {

//https://fazecast.github.io/jSerialComm/

        long inicio;
        long fim;
        long tempo;
        int opcao;
        Scanner sc = new Scanner(System.in);

        SerialPort[] p = SerialPort.getCommPorts();
        if (p.length == 0) {
            System.out.println("Portas indisponiveis");
            sleep(2000);
            System.exit(0);
        }
        int i = 1;
        int k=0;
        int escolha = 0;
        while(true) {
            for (SerialPort ps : p) {     //Seleção da porta série a usar
                System.out.println("  [" + i++ + "] " + "--> " + ps.getSystemPortName());
                k++;
            }
            escolha = sc.nextInt();
            if (escolha <= k && escolha > 0){
                k = escolha;
                break;
            }
            k=0;
            i=1;
        }
        SerialPort ps = p[--k];
        ps.openPort();

        ps.setComPortParameters(115200,8,0,0);   //Definir a Confg da Porta serie

        Scanner s = new Scanner(System.in);
        System.out.println("  [1] --> Enviar Ficheiro ");
        System.out.println("  [2] --> Receber ");
        System.out.println("  [3] --> Enviar mensagem");

        System.out.println("Opçao:");
        opcao = s.nextInt();

        switch (opcao) {
            case 1:
                inicio = System.currentTimeMillis();
                enviar(ps); //Método de envio
                fim = System.currentTimeMillis();
                tempo = (fim - inicio);
                System.out.println("enviado em "+ tempo + "ms");
                break;
            case 2:
                receber(ps);//Método para receber txt
                ps.closePort();
                break;
            case 3:
                enviarConversa(ps);
                ps.closePort();
                break;
        }
        System.exit(1);
    }

    // Parte específica receptor

    public static void receber(SerialPort port) throws IOException {

        byte[] cab = new byte[5];
        while (port.bytesAvailable() < 5 ) {//Espera pelo envio do último byte
        }
        port.readBytes(cab, 5);
        int val = (int)cab[3];
        byte[] bytes = new byte[val];
        int i;
        byte[] flag = new byte[1];
        while (port.bytesAvailable() < val) {//Espera pelo envio do último byte
        }{

            port.readBytes(flag,1 );
            if(flag[0]==1){
                i=1;
            }
        }
        port.readBytes(bytes, val);    //lê os bytes recebidos pela porta série
        Files.write(new File("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\texto.txt").toPath(), bytes);  //Cria o ficheiro de texto
        byte[] fix = new byte[10];
        while (port.bytesAvailable() < 10) {//Espera pelo envio do último byte
        }
        port.readBytes(fix, 10);
    }

    // Fim parte específica receptor

    //Funções de apoio emissor

    public static byte[] formularCabeçalho(int tamanho_dados, int n_envio, int tipo, int n_fluxo){

        byte[] cabecalho = new byte[5];
        int tamanho_total = 0;
        cabecalho[0] = 0b00000010;
        cabecalho[1] = (byte) tipo;
        cabecalho[2] = (byte) tamanho_dados;
        cabecalho[3] = (byte) n_envio;
        cabecalho[4] = (byte) n_fluxo;
        cabecalho[5] = '\0';
        return cabecalho;
    }
    public static byte[] trama_inicio(int tamanho_file, String tipo_file, String nome){
        byte[] trama = new byte[22];
        trama[0]= 0b00000010;
        trama[1]= 0b00000000;//hello
        trama[2] = (byte) tamanho_file;
        byte aux[] = tipo_file.getBytes();
        System.arraycopy(aux, 0, trama, 3, 6);
        byte aux2[] = tipo_file.getBytes();
        System.arraycopy(aux2, 0, trama, 9, 12);
        trama[21]= 0b00000011;
        trama[22]='\0';

        return trama;
    }

    //Fim funções de apoio emissor

    //Início para a função principal do emissor

    //Método para enviar o ficheiro de texto
    public static void enviar(SerialPort port) throws IOException
    {
        int b=32;
        Scanner scan = new Scanner(System.in);
        //C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt
        System.out.println("Introduza path do ficheiro");
        String path = scan.nextLine();
        String[] partes = path.split("\\");
        String p="";
        for (String parte : partes) {
            p=parte;
        }
        String[] partes2 = p.split(".");

        byte[] bytesFromFile = Files.readAllBytes(Paths.get(path));//Converte o ficheiro de texto para um array de bytes
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        int cont=0;
        byte[] trama_inicial=trama_inicio(bytesFromFile.length, partes2[1], partes2[0]);
        while(true) {

            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                    port.writeBytes(trama_inicial,trama_inicial.length);
                }
            }
            if(i==1){
                if(bytesFromFile.length<b){
                    b = bytesFromFile.length - j; //Assim evitamos a exception OutOfBounds
                }
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                j=j+b;
                System.out.println("Resultado:" );
                byte[] cab=formularCabeçalho(cont, subArray.length, 3, 0);
                byte[] subArray2 = Arrays.copyOfRange(subArray,cab.length,cab.length+j);
                port.writeBytes(subArray2,subArray2.length);  //Envia para a porta série o array de bytes
                cont++;
                i=0;
            }

        }

    }
    public static void enviarConversa(SerialPort port) throws IOException
    {
        int b=32;

        byte[] bytesFromFile = Files.readAllBytes(Paths.get("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt"));//Converte o ficheiro de texto para um array de bytes
        //ArrayDataEncoder encoder_temp = getEncoder(bytesFromFile,)
        if(bytesFromFile.length<b){
            b=bytesFromFile.length;
        }
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        while(true)
        {
            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                }
            }
            if(i==1){
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
                j=j+b;
                i=0;
            }

        }

    }
    //Fim parte principal emissão

}