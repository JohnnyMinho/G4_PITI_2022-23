import com.backblaze.erasure.ReedSolomon;
import com.fazecast.jSerialComm.SerialPort;
import static java.lang.Thread.sleep;
import static net.fec.openrq.parameters.ParameterChecker.maxAllowedDataLength;
import static net.fec.openrq.parameters.ParameterChecker.minAllowedNumSourceBlocks;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import net.fec.openrq.*;
import net.fec.openrq.encoder.DataEncoder;
import net.fec.openrq.encoder.SourceBlockEncoder;
import net.fec.openrq.parameters.FECParameters;

import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Array;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class F1_2 implements MetodosParaConsola{

    private MétodosCorrErros CorrErros= new MétodosCorrErros(); //Para aceder aos métoos da correção de erros
    private VisualizadordeFicheiros VerFile = new VisualizadordeFicheiros();

    public static final long MAX_DATA_LEN = 32; //O Máximo de bytes por bloco é 32 bytes, os bytes de paridade que acompanham os mesmos na mensagem, não fazem parte deste limite

    public void main(String[] args) throws IOException, InterruptedException
    {

//https://fazecast.github.io/jSerialComm/

    }

    //Parte Funções de geração de dados para o GUI
        public void Gerar_Menu(){
            System.out.println("*******************************************");
            System.out.println("* Transmissao otica sob infravermelhos *");
            System.out.println("* Trabalho realizado por: Grupo 4           *");
            System.out.println("* Curso: MIETI                                         *");
            System.out.println("*******************************************");
            System.out.println("Por uma questao de simplicidade, agora conseguimos escolher tanto as portas serie\n tal como as opcoes de funcionamento a partir desta interface grafica");
            System.out.println("Escreva o path do ficheiro a enviar");
            System.out.println("Para utilizar alguma das opcoes tem de fazer o seguinte\n Envio - Digite e introduza a diretoria do ficheiro a enviar. \n Receber - Digite e introduz a diretoria onde quer guardar o ficheiro");
        }

        public void Selection_Menu(String op, SerialPort ps, String path, byte tipo){
        try {
            System.out.print("port"+ps);
            if(ps != null){
            switch (op) {
                case "1" -> enviar(ps,path,tipo); //Método de envio
                case "2" -> enviar(ps,path,tipo); //Método de envio para imagem
                case "3" -> receber(ps,path);//Método para receber txt
                case "4" -> enviarConversa(ps);
            }}else{
                System.out.print("Nao ha nenhum port selecionado, nao foi realizada qualquer op");
            }
        }catch (IOException e){
            System.out.println("Ocorreu um erro durante a execução a sua opção");
        }
        }

    //Parte Ports
    public SerialPort Connect_Port(String ps_name){
        SerialPort ps = SerialPort.getCommPort(ps_name);
        if(ps.openPort()) {
            ps.setComPortParameters(115200, 8, 0, 0);   //Definir a Confg da Porta serie
            return ps;
        }
        else{
            return null;
        }
    }

    public String Fechar_Port(SerialPort ps){
        if(ps.closePort()) {
            return "Port fechado com sucesso";
        }
        else{
            return "Port não foi fechado com sucesso";
        }
    }

    public String[] getCOMS() throws InterruptedException {
        SerialPort[] p = SerialPort.getCommPorts();
        ArrayList<String> ValoresPorts = new ArrayList<>();
        //String[] ValoresPorts = new String[p.length];
        if (p.length == 0) {
            System.out.println("Portas indisponiveis");
            sleep(2000);
            System.exit(0);
        }
        int i = 0;
        int k = 0;
            for (SerialPort ps : p) {     //Seleção da porta série a usar
                if(ps.getSystemPortName().contains("USB") || ps.getSystemPortName().contains("COM") ) {
                    ValoresPorts.add(ps.getSystemPortName());
                    k++;
                }
                i++;
            }
            String[] array_envio = new String[k+1];
            array_envio[0] = "Escolha um dos Ports";
            for(int n = 0; n<k; n++ ){
                array_envio[n+1] = ValoresPorts.get(n);
            }
        return array_envio;
    }

    // Parte específica receptor
    public void receber(SerialPort port, String Path_to_Store) throws IOException {
        ArrayList<Byte> todos_os_dados = new ArrayList<>();
        InputStream inputStream = port.getInputStream();
        boolean flag_hello_received = false; //Nós têmos de esperar pela primeira mensagem de hello para sabermos o nome e extensão de ficheiro.
        boolean stop_message_recb = false;
        String Nome_ficheiro = "";
        String Extensao_ficheiro = "";
        boolean ficheiro_text = false;
        boolean ficheiro_imagem = false;
        boolean mensagem_chat = false;
        String filename = Path_to_Store + Nome_ficheiro + Extensao_ficheiro;
        byte[] cab = new byte[5];
        //Como a trama que suporta o envio das informações, a Hello, têm um cabeçalho diferente, precisamos de verificar sempre se esta à parte das restantes.
        if (port.bytesAvailable() == 3) {
            byte[] buffer = new byte[3];
            inputStream.read(buffer);
            if (buffer[1] == 0b00000000) {
                byte[] cab_hello = new byte[3];
                port.readBytes(cab_hello, 3);
                flag_hello_received = true;
                byte[] dados = new byte[(int)cab_hello[2]];
                while (port.bytesAvailable() < (int)cab_hello[2]){
                    //Espera pelo envio de todos os bytes do cabecalho da trama do tipo hello
                }
                port.readBytes(dados,(int)cab_hello[2]);
                String resultado_decodificar = Arrays.toString(CorrErros.decodificarRS(dados));
                Extensao_ficheiro = resultado_decodificar.substring(0,6);
                Nome_ficheiro = resultado_decodificar.substring(7,18);
            }
        }
        if (flag_hello_received) {
            //Têmos de esperar que a mensagem de stop seja recebida para sabermos que deixamos de ter dados para ler e que podemos guardar os dados no ficheiro
            while (!stop_message_recb) {
                while (port.bytesAvailable() < 5) {
                    //Espera pelo envio do último byte
                }
                port.readBytes(cab, 5);
                if (cab[0] == 0b00000010) { //Se tivermos recebido a start flag, a qual indica que começamos a receber dados de uma trama de x tipo.
                    int quantidade_dados = (int) cab[3];
                    switch (cab[2]) {
                        case 0b00000000: //HELLO QUE INDICA O TIPO DE DADOS, EXTENSÃO E NOME DO FICHEIRO
                                //Como os dados já foram tratados, este ponto é simplesmente ignorado
                            break;
                        case 0b00000010: //Caso o ficheiro seja um txt ou algum tipo de ficheiro de leitura
                            ficheiro_text = true;
                            break;
                        case 0b00000011: //Caso o ficheiro seja uma imagem
                            ficheiro_imagem = true;
                            break;
                        case 0b00000100: //Caso seja uma mensagem de chat
                            mensagem_chat = true;
                            break;
                        case 0b00000101:
                            stop_message_recb = true;
                            break;
                    }
                    if(!stop_message_recb) {
                        byte[] dados = new byte[quantidade_dados]; //A quantidade de dados incluí os bytes de paridade

                        while (port.bytesAvailable() < quantidade_dados) {
                            //Espera que os dados estejam todos no buffer do port para serem lidos
                        }
                        port.readBytes(dados, quantidade_dados);
                        byte[] cauda = new byte[1];
                        while (port.bytesAvailable() != 1) {
                            //Espera pelo envio da cauda
                        }
                        port.readBytes(cauda, 1);
                        if (cauda[0] == 0b00000011) { //Se recebermos a stop flag, guardamos os dados desta trama e indicamos
                            byte[] resultado_decodificar = CorrErros.decodificarRS(dados); //Decodificamos os dados da trama recebida
                            todos_os_dados.addAll(Arrays.asList(toObject(resultado_decodificar))); //Foi indicado o fim da trama, logo os dados são adicionados
                        }
                    } else{
                        if(ficheiro_text) {
                            StringBuilder sb = new StringBuilder();
                            for (byte b : todos_os_dados) {
                                sb.append((char) b);
                            }
                            String para_file = sb.toString();
                            FileWriter fileWriter = new FileWriter(filename);
                            fileWriter.write(para_file);
                            fileWriter.close();
                        }
                        if(ficheiro_imagem){
                            byte[] byteArray = new byte[todos_os_dados.size()];
                            for (int i = 0; i < todos_os_dados.size(); i++) {
                                byteArray[i] = todos_os_dados.get(i);
                            }
                            ByteArrayInputStream bais = new ByteArrayInputStream(byteArray);

                            // Converte os bytes recebidos em uma imagem
                            BufferedImage image = ImageIO.read(bais);

                            // A imagem recebido é colocada na diretoria com o nome e extensão indicados
                            File outputFile = new File(filename);
                            ImageIO.write(image, Extensao_ficheiro, outputFile);
                        }
                        if(mensagem_chat){
                            //Ainda tenho de ver o que vou fazer nesta parte
                        }
                    }
                }


                /*
                byte[] fix = new byte[10];
                while (port.bytesAvailable() < 10) {
                }
                port.readBytes(fix, 10);
                */
            }
        }
    }

    // Fim parte específica receptor

    //Funções de apoio emissor

    public byte[] formularCabeçalho(int tamanho_dados, int n_envio, byte tipo, int n_fluxo){

        byte[] cabecalho = new byte[5];
        int tamanho_total = 0;
        cabecalho[0] = 0b00000010;
        cabecalho[1] = tipo;
        cabecalho[2] = (byte) tamanho_dados;
        cabecalho[3] = (byte) n_envio;
        cabecalho[4] = (byte) n_fluxo;
        cabecalho[5] = '\0';
        return cabecalho;
    }
    public byte[] trama_inicio(int tamanho_file, String tipo_file, String nome){
        byte aux[] = tipo_file.getBytes();
        byte[] tipo_file_codificado = CorrErros.codificarRS(aux);
        byte aux2[] = nome.getBytes();
        byte[] nome_file_codificado = CorrErros.codificarRS(aux2);
        byte[] trama = new byte[5+nome_file_codificado.length+tipo_file_codificado.length];
        trama[0]= 0b00000010;
        trama[1]= 0b00000000;//hello
        trama[2] = (byte) (nome_file_codificado.length+tipo_file_codificado.length);
        System.arraycopy(aux, 0, trama, 3, nome_file_codificado.length);
        System.arraycopy(aux2, 0, trama, 9, tipo_file_codificado.length);
        trama[3+nome_file_codificado.length+tipo_file_codificado.length]= 0b00000011;
        trama[4+nome_file_codificado.length+tipo_file_codificado.length]='\0';

        return trama;
    }

    //Fim funções de apoio emissor

    //Início para a função principal do emissor

    //Método para enviar o ficheiro de texto
    public void enviar(SerialPort port, String path,byte tipo) throws IOException
    {
        int b=32;
        //C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt
        System.out.println(path);
        String[] partes = path.split(String.valueOf("/"));
        System.out.println(Arrays.toString(partes));
        if(partes.length == 1){
            partes = path.split(String.valueOf("/"));
        }
        String[] partes2 = partes[partes.length-1].split("\\.");
        System.out.println(Arrays.toString(partes2));
        byte[] bytesFromFile = Files.readAllBytes(Paths.get(path));//Converte o ficheiro de texto para um array de bytes
        int n_bytes_file = bytesFromFile.length;
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        int cont=0;
        byte[] trama_inicial=trama_inicio(bytesFromFile.length, partes2[1], partes2[0]);
        while(true) {
            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                    port.writeBytes(trama_inicial,trama_inicial.length);
                }
            }
            if(i==1){
                if(n_bytes_file<b){
                    b = n_bytes_file - j; //Assim evitamos a exception OutOfBounds
                }else{
                    n_bytes_file = n_bytes_file-b;
                    b = n_bytes_file;
                }
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b); //Tiramos os bytes do ficheiro em blocos do tamanho j+b
                byte[] bytes_codificados = CorrErros.codificarRS(subArray);
                j=j+b;
                System.out.println("Resultado:" );
                byte[] cab=formularCabeçalho(cont, subArray.length, tipo, 0); //Formular o cabeçalho
                byte[] subArray2 = new byte[cab.length+b+1];
                subArray2 = Arrays.copyOfRange(cab, 0, cab.length);
                subArray2 = Arrays.copyOfRange(subArray,cab.length+1,cab.length+b);
                subArray2[cab.length+b+1] = 0b00000011;
                char[] tamanho = String.valueOf(bytes_codificados).toCharArray();
                byte[] tamanho_byte = new byte[tamanho.length];
                for(int n = 0; n<tamanho.length; n++){
                    tamanho_byte[n] = (byte) tamanho[n];
                }
                System.out.println(tamanho);
                port.writeBytes(tamanho_byte,tamanho.length);
                port.writeBytes(bytes_codificados,bytes_codificados.length);  //Envia para a porta série o array de bytes
                cont++;
                i=0;
            }

        }

    }
    public void enviarConversa(SerialPort port) throws IOException
    {
        int b=32;

        byte[] bytesFromFile = Files.readAllBytes(Paths.get("C:\\Users\\Marco\\Desktop\\PITI\\PITI\\teste.txt"));//Converte o ficheiro de texto para um array de bytes
        //ArrayDataEncoder encoder_temp = getEncoder(bytesFromFile,)
        if(bytesFromFile.length<b){
            b=bytesFromFile.length;
        }
        int i=0,j=0;
        byte[] flag =new byte[1];
        flag[0]=0;
        while(true)
        {
            while(i==0){
                port.readBytes(flag,1 );
                if(flag[0]==1){
                    i=1;
                }
            }
            if(i==1){
                byte[] subArray = Arrays.copyOfRange(bytesFromFile, j, j+b);
                port.writeBytes(subArray,b);  //Envia para a porta série o array de bytes
                j=j+b;
                i=0;
            }

        }

    }
    private static Byte[] toObject(byte[] byteArray) {
        Byte[] byteObjects = new Byte[byteArray.length];
        for (int i = 0; i < byteArray.length; i++) {
            byteObjects[i] = byteArray[i];
        }
        return byteObjects;
    }
    //Fim parte principal emissão

}