import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;

public class ConsolaGUI extends JFrame implements ActionListener {
    private JTextArea textArea;
    private JTextField textField;
    private PrintStream standardOut;

    public ConsolaGUI() {
        super("Console");

        // Create the text area
        textArea = new JTextArea();
        textArea.setEditable(false);

        // Redirect System.out to the text area
        standardOut = System.out;
        PrintStream printStream = new PrintStream(new CustomOutputStream(textArea));
        System.setOut(printStream);
        System.setErr(printStream);

        // Create the text field
        textField = new JTextField();
        textField.addActionListener(this);

        // Create the scroll pane and add the text area
        JScrollPane scrollPane = new JScrollPane(textArea);

        // Set the layout and add components to the frame
        setLayout(new BorderLayout());
        add(scrollPane, BorderLayout.CENTER);
        add(textField, BorderLayout.SOUTH);

        // Set frame properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setVisible(true);

        // Request focus on the text field
        textField.requestFocus();
    }

    public void actionPerformed(ActionEvent e) {
        String command = textField.getText();
        executeCommand(command);
        textField.setText("");
    }

    private void executeCommand(String command) {
        // Handle the command here
        System.out.println("> " + command);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConsolaGUI());
    }
}

class CustomOutputStream extends java.io.OutputStream {
    private JTextArea textArea;

    public CustomOutputStream(JTextArea textArea) {
        this.textArea = textArea;
    }

    public void write(int b) {
        textArea.append(String.valueOf((char) b));
        textArea.setCaretPosition(textArea.getDocument().getLength());
    }
}